export { default as spinner } from "./spinner.png";
export { default as Logo } from "./farmsteadlogo.png";
export { default as WhiteLogo } from "./whitelogo.png";
export { default as Logo2 } from "./Logo.png";
export { default as farmsteadlogo } from "./farmsteadlogo.png";
