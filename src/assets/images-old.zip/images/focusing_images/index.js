export { default as no_poverty } from "./family.png";
export { default as zero_hunger } from "./famine.png";
export { default as economic_growth } from "./economy.png";
export { default as infrastructure } from "./production.png";
export { default as cities } from "./cities.png";
export { default as consumtion_production } from "./loop.png";

export { default as ico_small } from "./ico_small.png";
export { default as world } from "./world.png";
export { default as world2 } from "./world2.png";

// export { default as background } from "./background.jpg";
export { default as background } from "./strawberry-field-min.jpg";
