export { default as blog_shape } from "./blog-shape.png";

export { default as corn } from "./corn-stalk-ready-harvest-field-min.jpg";
export { default as seed } from "./selective-focus-shot-group-green-sprouts-growing-out-from-soil-min.jpg";
export { default as feildwrap } from "./lettuce.jpg";
export { default as lab } from "./responsive_big_webp_Gw7KwnnCIYqejjA7vIfE2qEeD2UL1kBqQu3UCknjU0s.webp";
