export { default as palm } from "./palm.jpg";
export { default as greenleafs } from "./greenleafs.jpg";
export { default as waving } from "./waving.png";
export { default as test } from "./test.jpg";
