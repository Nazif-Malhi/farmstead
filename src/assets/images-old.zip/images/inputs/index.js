export { default as labortarty_test } from "./labortary.jpg";
