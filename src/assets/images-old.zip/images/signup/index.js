export { default as Custom } from "./features.png";
export { default as Standard } from "./standard.png";
