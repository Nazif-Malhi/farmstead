export { default as Banner } from "./Banner.png";
export { default as Shape } from "./Shape.png";
export { default as Arrow } from "./Arrow.svg";
export { default as Leaf1 } from "./Leaf1.png";
export { default as Leaf2 } from "./Leaf2.png";
export { default as Leaf3 } from "./Leaf3.png";
export { default as Leaf4 } from "./Leaf4.png";

export { default as grass } from "./grass.png";
export { default as rice } from "./rice.png";
export { default as tractor } from "./tractor.png";
export { default as vegetable } from "./vegetable.png";
export { default as vegetable2 } from "./vegetable2.png";
export { default as wheat } from "./wheat.png";
