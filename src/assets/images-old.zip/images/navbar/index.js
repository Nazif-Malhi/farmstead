export { default as upgrade } from "./upgrade.jpeg";
