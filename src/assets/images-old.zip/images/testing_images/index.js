export { default as sunnylandscape } from "./sunnylandscape.png";
export { default as cardshapehover } from "./card-shape-hover.png";
export { default as cardshape } from "./card-shape.png";
export { default as cultivate } from "./cultivate.jpg";

export { default as fertilizer } from "./fertilizer.jpg";
export { default as watering } from "./watering.jpg";

export { default as tractoranime } from "./tractoranime.gif";
export { default as pest1 } from "./pest1.jpeg";
export { default as pest2 } from "./pest2.jpg";
export { default as cropDisease } from "./cropDisease.jpg";
